# Lemonade-Android-App

- Android Studio project
- Single activity application
- Course - Unit 1 project of Android basics in Kotlin in Google Developer (@AndroidDev, #AndroidBasics)
